const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Create connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'car_showroom',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Test connection on startup
(async () => {
  try {
    const conn = await pool.getConnection();
    console.log('----------------------------------------------------');
    console.log('✓ Successfully connected to MySQL Database!');
    console.log(`✓ DB Name: ${process.env.DB_NAME || 'car_showroom'}`);
    console.log('----------------------------------------------------');
    conn.release();
  } catch (err) {
    console.error('----------------------------------------------------');
    console.error('✗ ERROR: Failed to connect to MySQL database!');
    console.error(`  Host: ${process.env.DB_HOST || 'localhost'}:${process.env.DB_PORT || 3306}`);
    console.error(`  User: ${process.env.DB_USER || 'root'}`);
    console.error(`  Database: ${process.env.DB_NAME || 'car_showroom'}`);
    console.error('  Details:', err.message);
    console.error('\n  👉 Troubleshooting checklist:');
    console.error('  1. Verify MySQL Server is running on your machine.');
    console.error('  2. Run database.sql in MySQL Workbench to initialize the schema.');
    console.error('  3. Open .env and adjust the DB_PASSWORD and details if required.');
    console.error('----------------------------------------------------');
  }
})();

// Helper to format Date objects as YYYY-MM-DD cleanly without timezone offset shifts
const formatDate = (dateVal) => {
  if (!dateVal) return '';
  const d = new Date(dateVal);
  if (isNaN(d.getTime())) return '';
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
};

// ── BRANDS ──────────────────────────────────────────────────────────────────
app.get('/api/brands', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Brand');
    res.json(rows.map(b => ({
      id: b.brand_id,
      name: b.brand_name,
      country: b.country
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── FLEET / CARS ─────────────────────────────────────────────────────────────
app.get('/api/cars', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Car');
    res.json(rows.map(c => ({
      id: c.car_id,
      brandId: c.brand_id,
      model: c.model,
      year: c.year,
      color: c.color,
      price: parseFloat(c.price),
      status: c.status
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/cars', async (req, res) => {
  try {
    const { brandId, model, year, color, price, status } = req.body;
    if (!brandId || !model || !price) {
      return res.status(400).json({ error: 'Brand, Model and Price are required' });
    }
    const [result] = await pool.query(
      'INSERT INTO Car (brand_id, model, year, color, price, status) VALUES (?, ?, ?, ?, ?, ?)',
      [brandId, model, year || null, color || null, price, status || 'Available']
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/cars/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM Car WHERE car_id = ?', [id]);
    res.json({ success: true, message: `Car with ID ${id} deleted` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── CUSTOMERS / CLIENTS ──────────────────────────────────────────────────────
app.get('/api/customers', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Customer');
    res.json(rows.map(c => ({
      id: c.customer_id,
      name: c.name,
      phone: c.phone || '',
      email: c.email || '',
      address: c.address || '',
      joined: formatDate(c.joined_on)
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/customers', async (req, res) => {
  try {
    const { name, phone, email, address } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'Customer Name is required' });
    }
    const [result] = await pool.query(
      'INSERT INTO Customer (name, phone, email, address, joined_on) VALUES (?, ?, ?, ?, CURDATE())',
      [name, phone || null, email || null, address || null]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── EMPLOYEES / CREW ──────────────────────────────────────────────────────────
app.get('/api/employees', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Employee');
    res.json(rows.map(e => ({
      id: e.emp_id,
      name: e.name,
      role: e.role || '',
      phone: e.phone || '',
      salary: parseFloat(e.salary || 0)
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/employees', async (req, res) => {
  try {
    const { name, role, phone, salary } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'Employee Name is required' });
    }
    const [result] = await pool.query(
      'INSERT INTO Employee (name, role, phone, salary, hired) VALUES (?, ?, ?, ?, CURDATE())',
      [name, role || null, phone || null, salary || 0]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── ORDERS ────────────────────────────────────────────────────────────────────
app.get('/api/orders', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Orders');
    res.json(rows.map(o => ({
      id: o.order_id,
      customerId: o.customer_id,
      carId: o.car_id,
      empId: o.emp_id,
      date: formatDate(o.order_date)
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Complete sales order creation with atomic SQL transaction to mark car status as 'Sold'
app.post('/api/orders', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { customerId, carId, empId, date } = req.body;

    if (!customerId || !carId || !empId) {
      throw new Error('Customer, Car and Employee are required');
    }

    const orderDate = date || formatDate(new Date());

    // 1. Insert order
    const [orderResult] = await conn.query(
      'INSERT INTO Orders (customer_id, car_id, emp_id, order_date) VALUES (?, ?, ?, ?)',
      [customerId, carId, empId, orderDate]
    );

    // 2. Mark car status as 'Sold'
    await conn.query('UPDATE Car SET status = "Sold" WHERE car_id = ?', [carId]);

    await conn.commit();
    res.status(201).json({ id: orderResult.insertId });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ error: err.message });
  } finally {
    conn.release();
  }
});

// ── PAYMENTS / FINANCE ───────────────────────────────────────────────────────
app.get('/api/payments', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Payment');
    res.json(rows.map(p => ({
      id: p.payment_id,
      orderId: p.order_id,
      amount: parseFloat(p.amount || 0),
      mode: p.payment_mode,
      date: formatDate(p.payment_date)
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/payments', async (req, res) => {
  try {
    const { orderId, amount, mode, date } = req.body;
    if (!orderId || !amount || !mode) {
      return res.status(400).json({ error: 'Order, Amount and Payment Mode are required' });
    }
    const paymentDate = date || formatDate(new Date());
    const [result] = await pool.query(
      'INSERT INTO Payment (order_id, amount, payment_mode, payment_date) VALUES (?, ?, ?, ?)',
      [orderId, amount, mode, paymentDate]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── TEST DRIVES ──────────────────────────────────────────────────────────────
app.get('/api/testdrives', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM TestDrive');
    res.json(rows.map(td => ({
      id: td.td_id,
      customerId: td.customer_id,
      carId: td.car_id,
      date: formatDate(td.td_date),
      feedback: td.feedback || ''
    })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/testdrives', async (req, res) => {
  try {
    const { customerId, carId, date, feedback } = req.body;
    if (!customerId || !carId || !date) {
      return res.status(400).json({ error: 'Customer, Car and Booking Date are required' });
    }
    const [result] = await pool.query(
      'INSERT INTO TestDrive (customer_id, car_id, td_date, feedback) VALUES (?, ?, ?, ?)',
      [customerId, carId, date, feedback || null]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start Server
app.listen(PORT, () => {
  console.log(`\n🚀 AutoElite backend is running on http://localhost:${PORT}`);
});
