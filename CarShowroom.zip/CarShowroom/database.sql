-- ============================================================
--  CAR SHOWROOM MANAGEMENT SYSTEM — MySQL Database
--  Run this in MySQL Workbench or via: mysql -u root -p < database.sql
-- ============================================================

DROP DATABASE IF EXISTS car_showroom;
CREATE DATABASE car_showroom;
USE car_showroom;

-- ── 1. BRAND ─────────────────────────────────────────────────
CREATE TABLE Brand (
    brand_id   INT PRIMARY KEY AUTO_INCREMENT,
    brand_name VARCHAR(60)  NOT NULL,
    country    VARCHAR(60)
);

-- ── 2. CAR ───────────────────────────────────────────────────
CREATE TABLE Car (
    car_id    INT PRIMARY KEY AUTO_INCREMENT,
    brand_id  INT NOT NULL,
    model     VARCHAR(80)  NOT NULL,
    year      YEAR,
    color     VARCHAR(40),
    price     DECIMAL(12,2),
    status    ENUM('Available','Sold','Reserved') DEFAULT 'Available',
    FOREIGN KEY (brand_id) REFERENCES Brand(brand_id) ON DELETE CASCADE
);

-- ── 3. CUSTOMER ──────────────────────────────────────────────
CREATE TABLE Customer (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    phone       VARCHAR(15),
    email       VARCHAR(100),
    address     TEXT,
    joined_on   DATE DEFAULT (CURRENT_DATE)
);

-- ── 4. EMPLOYEE ──────────────────────────────────────────────
CREATE TABLE Employee (
    emp_id  INT PRIMARY KEY AUTO_INCREMENT,
    name    VARCHAR(100) NOT NULL,
    role    VARCHAR(60),
    phone   VARCHAR(15),
    salary  DECIMAL(10,2),
    hired   DATE DEFAULT (CURRENT_DATE)
);

-- ── 5. ORDERS ────────────────────────────────────────────────
CREATE TABLE Orders (
    order_id    INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    car_id      INT NOT NULL,
    emp_id      INT NOT NULL,
    order_date  DATE NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (car_id)      REFERENCES Car(car_id),
    FOREIGN KEY (emp_id)      REFERENCES Employee(emp_id)
);

-- ── 6. PAYMENT ───────────────────────────────────────────────
CREATE TABLE Payment (
    payment_id   INT PRIMARY KEY AUTO_INCREMENT,
    order_id     INT NOT NULL,
    amount       DECIMAL(12,2),
    payment_mode ENUM('Cash','Card','Loan','UPI'),
    payment_date DATE NOT NULL,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);

-- ── 7. TEST DRIVE ────────────────────────────────────────────
CREATE TABLE TestDrive (
    td_id       INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    car_id      INT NOT NULL,
    td_date     DATE NOT NULL,
    feedback    TEXT,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (car_id)      REFERENCES Car(car_id)
);

-- ============================================================
--  SAMPLE DATA
-- ============================================================

INSERT INTO Brand (brand_name, country) VALUES
('Toyota',  'Japan'),
('Honda',   'Japan'),
('Ford',    'USA'),
('Hyundai', 'South Korea'),
('Porsche', 'Germany');

INSERT INTO Car (brand_id, model, year, color, price, status) VALUES
(1, 'Innova Crysta', 2023, 'White',    2500000.00, 'Available'),
(2, 'City ZX',       2024, 'Silver',   1500000.00, 'Available'),
(3, 'Mustang GT',    2022, 'Black',    7500000.00, 'Sold'),
(4, 'Creta SX',      2024, 'Red',      1800000.00, 'Available'),
(1, 'Fortuner',      2023, 'Grey',     3800000.00, 'Reserved'),
(5, 'Cayenne GTS',   2024, 'Obsidian',18500000.00, 'Available');

INSERT INTO Customer (name, phone, email, address, joined_on) VALUES
('Riya Sharma',  '9876543210', 'riya@gmail.com',  'Chennai',   '2024-01-10'),
('Arjun Mehta',  '9123456780', 'arjun@gmail.com', 'Mumbai',    '2024-02-05'),
('Sneha Pillai', '9001234567', 'sneha@gmail.com', 'Bangalore', '2024-03-22');

INSERT INTO Employee (name, role, phone, salary, hired) VALUES
('Karan Singh', 'Sales Executive', '9988776655', 35000.00, '2023-06-01'),
('Priya Nair',  'Manager',         '9977665544', 60000.00, '2022-09-15'),
('Dev Khanna',  'Sales Executive', '9812345678', 32000.00, '2024-01-20');

INSERT INTO Orders (customer_id, car_id, emp_id, order_date) VALUES
(1, 2, 1, '2024-03-15'),
(2, 3, 2, '2024-04-10');

UPDATE Car SET status = 'Sold' WHERE car_id = 3;

INSERT INTO Payment (order_id, amount, payment_mode, payment_date) VALUES
(1, 1500000.00, 'Loan', '2024-03-16'),
(2, 7500000.00, 'Card', '2024-04-11');

INSERT INTO TestDrive (customer_id, car_id, td_date, feedback) VALUES
(1, 1, '2024-03-10', 'Smooth drive, loved the comfort!'),
(2, 3, '2024-04-05', 'Extremely powerful, thrilling experience.'),
(3, 6, '2024-04-18', 'Luxurious feel, premium quality.');

-- ============================================================
--  USEFUL QUERIES (for reference / viva)
-- ============================================================

-- 1. All available cars with brand
-- SELECT c.car_id, b.brand_name, c.model, c.year, c.color, c.price
-- FROM Car c JOIN Brand b ON c.brand_id = b.brand_id
-- WHERE c.status = 'Available';

-- 2. Full order details
-- SELECT o.order_id, cu.name AS Customer, CONCAT(b.brand_name,' ',ca.model) AS Car,
--        e.name AS Executive, o.order_date
-- FROM Orders o
-- JOIN Customer cu ON o.customer_id = cu.customer_id
-- JOIN Car ca      ON o.car_id      = ca.car_id
-- JOIN Brand b     ON ca.brand_id   = b.brand_id
-- JOIN Employee e  ON o.emp_id      = e.emp_id;

-- 3. Total revenue
-- SELECT SUM(amount) AS Total_Revenue FROM Payment;

-- 4. Cars sold per brand
-- SELECT b.brand_name, COUNT(o.order_id) AS Cars_Sold
-- FROM Orders o JOIN Car c ON o.car_id=c.car_id JOIN Brand b ON c.brand_id=b.brand_id
-- GROUP BY b.brand_name ORDER BY Cars_Sold DESC;

-- 5. Test drive history
-- SELECT cu.name, CONCAT(b.brand_name,' ',ca.model) AS Car, t.td_date, t.feedback
-- FROM TestDrive t
-- JOIN Customer cu ON t.customer_id = cu.customer_id
-- JOIN Car ca      ON t.car_id = ca.car_id
-- JOIN Brand b     ON ca.brand_id = b.brand_id;
